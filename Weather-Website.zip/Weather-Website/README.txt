WEATHER FORECAST WEBSITE

Files:
- index.html: Complete project (HTML, CSS and JavaScript)

How to run:
1. Extract this ZIP file.
2. Open the extracted folder in VS Code.
3. Open index.html using Live Server, or open it in a browser.
4. To get live weather data, create a free API key at:
   https://openweathermap.org/api
5. In index.html, replace YOUR_API_KEY in:
   const API_KEY = "YOUR_API_KEY";
6. Save and refresh the page.

Note:
The website needs an internet connection and a valid OpenWeather API key
to fetch live weather information.
